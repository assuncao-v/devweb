<?php
	$autenticado = true;
?>